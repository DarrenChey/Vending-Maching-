package vendingmachine;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import javax.swing.JOptionPane;
public class ReportDrinks extends javax.swing.JFrame {


    public ReportDrinks() {
        initComponents();
        generateMostPopularDrinksReport();
        setDefaultCloseOperation(ReportDrinks.DISPOSE_ON_CLOSE);
    }
    
    
private void generateMostPopularDrinksReport() {
    
    jTextAreaDrinksReport.setText("\t-------------REPORT-------------\n");
    jTextAreaDrinksReport.append("\n Most Popular Drinks:\n");

    Map<String, Integer> drinkFrequency = new HashMap<>();

    try (BufferedReader reader = new BufferedReader(new FileReader("purchaseHistory.txt"))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(", ");
            if (parts.length >= 3) {
                String drinkName = parts[2];
                drinkFrequency.put(drinkName, drinkFrequency.getOrDefault(drinkName, 0) + 1);
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }

    List<Map.Entry<String, Integer>> sortedList = new ArrayList<>(drinkFrequency.entrySet());
    sortedList.sort((entry1, entry2) -> entry2.getValue().compareTo(entry1.getValue()));

    int rank = 1;
    for (Map.Entry<String, Integer> entry : sortedList) {
        String drinkName = entry.getKey();
        int frequency = entry.getValue();
        jTextAreaDrinksReport.append("\n" +rank + ". " + drinkName + " (Purchased " + frequency + " times)\n");
        rank++;
        
        
    }

}
    
@SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaDrinksReport = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jTextAreaDrinksReport.setColumns(20);
        jTextAreaDrinksReport.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jTextAreaDrinksReport.setRows(5);
        jScrollPane1.setViewportView(jTextAreaDrinksReport);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 450, 560));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                

}
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ReportDrinks.class
.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        

} catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ReportDrinks.class
.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        

} catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ReportDrinks.class
.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        

} catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ReportDrinks.class
.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ReportDrinks().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextAreaDrinksReport;
    // End of variables declaration//GEN-END:variables
}
