package vendingmachine;

import javax.swing.*;
import java.awt.Font;
import java.io.*;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.HashMap;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.List;
import java.util.ArrayList;

/**
 *
 * @author Darren
 */
public class customer_purchase extends javax.swing.JFrame {

    private int totalAmount = 0;
    private Map<String, Integer> drinkQuantityMap = new LinkedHashMap<>();
    private JTextArea jReceipt;
    private Map<String, Integer> drinkMaxQuantityMap = new HashMap<>();
    private Map<String, Integer> tempDrinkQuantityMap = new HashMap<>();
    private Map<Integer, String> drinkIdNameMap = new HashMap<>(); 
    private Map<Integer, JLabel> labelMap = new HashMap<>();
    private Map<Integer, JLabel> priceMap = new HashMap<>(); 
    

    
    

    public customer_purchase() {
        initComponents();
        tempDrinkQuantityMap.putAll(drinkQuantityMap); // Copy initial quantities
        jQuantity.setText("Total Quantity: 0");
        jTotal.setText("Total: RM 0.00");
        CartArea.setEditable(false);
        jInsertMoney.setText("RM");
        jChange.setEditable(false);
        jReceipt = new JTextArea();
        jReceipt.setEditable(false);
        jScrollPane2.setViewportView(jReceipt);

        priceMap.put(5, jLabel12);
        priceMap.put(1, jLabel7);
        priceMap.put(6, jLabel11);
        priceMap.put(9, jLabel10);
        priceMap.put(10, jLabel8);
        priceMap.put(7, jLabel17Cola);
        priceMap.put(8, jLabel25);
        priceMap.put(4, jLabel13);
        priceMap.put(2, jLabel24);
        priceMap.put(3, jLabel23);
        loadLabelPriceFromFile ("D:/Darren/Documents/NetBeansProjects/VendingMachine/drinksData.txt");

        
        labelMap.put(5, jLabel30apple);
        labelMap.put(1, jLabel31coconut);
        labelMap.put(6, jLabel32lemon);
        labelMap.put(9, jLabel33coffee);
        labelMap.put(10, jLabel36pepsi);
        labelMap.put(7, jLabel37cola);
        labelMap.put(8, jLabel38energy);
        labelMap.put(4, jLabel100plus);
        labelMap.put(2, jLabel27icedLemon);
        labelMap.put(3, jLabel28MineralWater);
        
        loadLabelDataFromFile ("D:/Darren/Documents/NetBeansProjects/VendingMachine/drinksData.txt");

// Load drink data and update text field availability
        loadDrinkDataFromFile("D:/Darren/Documents/NetBeansProjects/VendingMachine/drinksData.txt");

        try {
            String filePath = "D:/Darren/Documents/NetBeansProjects/VendingMachine/drinksData.txt"; // Replace with the actual file path
            FileReader fileReader = new FileReader(filePath);
            BufferedReader reader = new BufferedReader(fileReader);
            String line;
            int drinkId = 1; // Start with the first drink ID
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String drinkName = parts[1].trim();
                    int maxQuantity = Integer.parseInt(parts[2].trim());

                    drinkMaxQuantityMap.put(drinkName, maxQuantity); // Store max quantity in the map
                    drinkIdNameMap.put(drinkId, drinkName); // Store drink ID and name
                    drinkId++; // Increment the drink ID
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public class Drink {

        private int id;
        private String name;
        private double price;
        private int maxQuantity;
        private int quantity;

        public Drink(int id, String name, double price, int maxQuantity) {
            this.id = id;
            this.name = name;
            this.price = price;
            this.maxQuantity = maxQuantity;
            this.quantity = 0;

        }

        // Create for the fields
        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public double getPrice() {
            return price;
        }

        public int getMaxQuantity() {
            return maxQuantity;
        }

        public int getQuantity() {
            return quantity;
        }

        public void incrementQuantity() {
            if (quantity < maxQuantity) {
                quantity++;
            }
        }

        public void setQuantity(int newQuantity) {
            if (newQuantity >= 0 && newQuantity <= maxQuantity) {
                quantity = newQuantity;
            }
        }

        public void decrementQuantity(int decrementBy) {
            if (decrementBy >= 0 && decrementBy <= quantity) {
                quantity -= decrementBy;
            }
        }

    }
     List<Drink> drinksList = new ArrayList<>(); // Add this field

    private Drink getDrinkById(int drinkId) {
        if (drinkId >= 1 && drinkId <= drinksList.size()) {
            return drinksList.get(drinkId - 1); // Index in list is one less than the ID
        }
        return null; // Invalid drink ID
    }
    


    private void updateDrinkQuantityInFile(String drinkName, int quantityChange) {
        try {
            String filePath = "D:/Darren/Documents/NetBeansProjects/VendingMachine/drinksData.txt";
            File inputFile = new File(filePath);

            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            StringBuilder modifiedContent = new StringBuilder();

            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    int id = Integer.parseInt(parts[0].trim());
                    String currentDrinkName = parts[1].trim();
                    double drinkPrice = Double.parseDouble(parts[2].trim());
                    int currentMaxQuantity = Integer.parseInt(parts[3].trim());

                    if (currentDrinkName.equals(drinkName)) {
                        int newMaxQuantity = Math.max(0, currentMaxQuantity - quantityChange);
                        line = id + ", " + currentDrinkName + ", " + drinkPrice + ", " + newMaxQuantity; // Update the line with the correct values
                    }
                }
                modifiedContent.append(line).append(System.lineSeparator());
            }

            reader.close();

            // Write the modified content back to the same file
            BufferedWriter writer = new BufferedWriter(new FileWriter(inputFile));
            writer.write(modifiedContent.toString());
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void updateTotalQuantity() {
        int totalQuantity = 0;
        for (Drink drink : drinksList) {
            totalQuantity += drink.getQuantity();
        }
        jQuantity.setText("Total Quantity: " + totalQuantity);
    }

    private void updateTotalAmount() {
        double totalAmount = 0.0;
        for (Drink drink : drinksList) {
            totalAmount += drink.getQuantity() * drink.getPrice();
        }
        jTotal.setText("Total: RM " + String.format("%.2f", totalAmount));
    }




private void handleDrinkButton(int drinkId) {
    Drink selectedDrink = getDrinkById(drinkId);
    if (selectedDrink == null) {
        // Handle invalid drink ID or name
                System.out.println("Selected drink is null.");

        return;
    }

    int maxQuantity = selectedDrink.getMaxQuantity();
    int currentQuantity = selectedDrink.getQuantity();

    if (currentQuantity < maxQuantity) {
        // Increment the quantity only if it hasn't reached the maxQuantity
        selectedDrink.incrementQuantity();
        totalAmount += selectedDrink.getPrice();
        updateTotalAmount();
        updateTotalQuantity();
        updateCartArea();
        tempDrinkQuantityMap.put(selectedDrink.getName(), currentQuantity + 1);
    } else {
        // Handle maximum availability reached
        JOptionPane.showMessageDialog(this, "Maximum availability reached for " + selectedDrink.getName(), "Sold Out", JOptionPane.INFORMATION_MESSAGE);
    }
}


    private void updateCartArea() {
        CartArea.setText("");
        for (Drink drink : drinksList) {
            int drinkQuantity = drink.getQuantity();

            if (drinkQuantity > 0) { // Only include drinks with non-zero quantity in the cart area
                String drinkName = drink.getName();
                double drinkPrice = drink.getPrice();
                CartArea.append(drinkName + " [" + drinkQuantity + "] RM " + String.format("%.2f", drinkPrice) + "\n");
            }
        }
    }

    private void clearCart() {
        // Clear drink quantities and total amount
        for (Drink drink : drinksList) {
            drink.setQuantity(0); // Assuming there's a setQuantity method in the Drink class
        }
        totalAmount = 0;

        // Update total quantity and total amount displays
        updateTotalQuantity();
        updateTotalAmount();

        // Clear cart area
        CartArea.setText("");

        

        // Clear temporary drink quantity map
        tempDrinkQuantityMap.clear();
        
    }
    
    
  
    
private void loadLabelPriceFromFile(String filePath) {
    try {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 4) {
                int id = Integer.parseInt(parts[0].trim());
                double price = Double.parseDouble(parts[2].trim()); // Get the price value

                JLabel label = priceMap.get(id);
                if (label != null) {
                    label.setText(String.format("RM %.2f", price)); // Set the price value with "RM" prefix
                }
            }
        }
        reader.close();
    } catch (IOException e) {
        e.printStackTrace();
    }

}
       
    private void loadDrinkDataFromFile(String filePath) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;
            int id = 1; // Start with the first drink ID
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) {
                    String name = parts[1].trim();
                    double price = Double.parseDouble(parts[2].trim());
                    int maxQuantity = Integer.parseInt(parts[3].trim());

                    Drink drink = new Drink(id, name, price, maxQuantity);
                    drinksList.add(drink);
                    id++; // Increment the drink ID
                }
            }

            reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    
    
private void loadLabelDataFromFile(String filePath) {
    try {
        BufferedReader reader = new BufferedReader(new FileReader(filePath));
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length == 4) {
                int id = Integer.parseInt(parts[0].trim());
                String name = parts[1].trim();

                JLabel label = labelMap.get(id);
                if (label != null) {
                    label.setText(name);
                }
            }
        }
        reader.close();
    } catch (IOException e) {
        e.printStackTrace();
    }

}
    

    private int getLastPurchaseIdFromFile(String filePath) {
        int lastId = 0;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filePath));
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(", ");
                if (parts.length >= 4) {
                    int id = Integer.parseInt(parts[0].trim());
                    lastId = Math.max(lastId, id);
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return lastId;
    }

 

private void savePurchaseHistoryToFile(String fileName, String content) {
    try {
        FileWriter fileWriter = new FileWriter(fileName, true);
        BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
        bufferedWriter.write(content);
        bufferedWriter.newLine();
        bufferedWriter.close();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
private boolean checkNum(String str) {
    try {
        Double.parseDouble(str);
        return true;
    } catch (NumberFormatException e) {
        return false;
    }
}


   
    
    


    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jLabel22 = new javax.swing.JLabel();
        btnCoconut = new javax.swing.JButton();
        btnPepsi = new javax.swing.JButton();
        btnlemontea = new javax.swing.JButton();
        btnWater = new javax.swing.JButton();
        btn100plus = new javax.swing.JButton();
        btnApple = new javax.swing.JButton();
        btnCoffee = new javax.swing.JButton();
        colabtn = new javax.swing.JButton();
        btnlemonade = new javax.swing.JButton();
        btnEnergydrink = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel26 = new javax.swing.JLabel();
        jLabel17Cola = new javax.swing.JLabel();
        jLabel28MineralWater = new javax.swing.JLabel();
        jLabel100plus = new javax.swing.JLabel();
        jLabel30apple = new javax.swing.JLabel();
        jLabel31coconut = new javax.swing.JLabel();
        jLabel32lemon = new javax.swing.JLabel();
        jLabel33coffee = new javax.swing.JLabel();
        jLabel27icedLemon = new javax.swing.JLabel();
        jLabel36pepsi = new javax.swing.JLabel();
        jLabel37cola = new javax.swing.JLabel();
        jLabel38energy = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jInsertMoney = new javax.swing.JTextField();
        jChange = new javax.swing.JTextField();
        jTotal = new javax.swing.JLabel();
        jQuantity = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnPurchase = new javax.swing.JButton();
        btnClearAll = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jRecipt = new javax.swing.JTextArea();
        jScrollPane1 = new javax.swing.JScrollPane();
        CartArea = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jPanel2.setBackground(new java.awt.Color(255, 51, 51));
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 4));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("DRINK VENDOR");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 20, 332, 59));

        jPanel3.setBackground(new java.awt.Color(255, 255, 204));
        jPanel3.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 51, 0), 4));
        jPanel3.setForeground(new java.awt.Color(102, 102, 102));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/coffee.png"))); // NOI18N
        jLabel3.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 30, 130, 160));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/cola.png"))); // NOI18N
        jLabel14.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 40, 110, 150));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/energy-drink.png"))); // NOI18N
        jLabel15.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 40, 110, 150));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/100plus.png"))); // NOI18N
        jLabel16.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 290, 120, -1));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/juice.png"))); // NOI18N
        jLabel18.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 300, 130, 140));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/coconut.png"))); // NOI18N
        jLabel19.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 290, 170, -1));

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/mineral-water.png"))); // NOI18N
        jLabel21.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 290, 100, 150));

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/pepsi.png"))); // NOI18N
        jLabel22.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 30, 110, 160));

        btnCoconut.setBackground(new java.awt.Color(0, 0, 0));
        btnCoconut.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnCoconut.setForeground(new java.awt.Color(255, 255, 255));
        btnCoconut.setText("ADD");
        btnCoconut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCoconutActionPerformed(evt);
            }
        });
        jPanel3.add(btnCoconut, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 480, 100, -1));

        btnPepsi.setBackground(new java.awt.Color(0, 0, 0));
        btnPepsi.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnPepsi.setForeground(new java.awt.Color(255, 255, 255));
        btnPepsi.setText("ADD");
        btnPepsi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPepsiActionPerformed(evt);
            }
        });
        jPanel3.add(btnPepsi, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 240, 100, -1));

        btnlemontea.setBackground(new java.awt.Color(0, 0, 0));
        btnlemontea.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnlemontea.setForeground(new java.awt.Color(255, 255, 255));
        btnlemontea.setText("ADD");
        btnlemontea.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlemonteaActionPerformed(evt);
            }
        });
        jPanel3.add(btnlemontea, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 480, 100, -1));

        btnWater.setBackground(new java.awt.Color(0, 0, 0));
        btnWater.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnWater.setForeground(new java.awt.Color(255, 255, 255));
        btnWater.setText("ADD");
        btnWater.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWaterActionPerformed(evt);
            }
        });
        jPanel3.add(btnWater, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 480, 100, -1));

        btn100plus.setBackground(new java.awt.Color(0, 0, 0));
        btn100plus.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btn100plus.setForeground(new java.awt.Color(255, 255, 255));
        btn100plus.setText("ADD");
        btn100plus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn100plusActionPerformed(evt);
            }
        });
        jPanel3.add(btn100plus, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 480, 100, -1));

        btnApple.setBackground(new java.awt.Color(0, 0, 0));
        btnApple.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnApple.setForeground(new java.awt.Color(255, 255, 255));
        btnApple.setText("ADD");
        btnApple.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAppleActionPerformed(evt);
            }
        });
        jPanel3.add(btnApple, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 480, 100, -1));

        btnCoffee.setBackground(new java.awt.Color(0, 0, 0));
        btnCoffee.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnCoffee.setForeground(new java.awt.Color(255, 255, 255));
        btnCoffee.setText("ADD");
        btnCoffee.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCoffeeActionPerformed(evt);
            }
        });
        jPanel3.add(btnCoffee, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 240, 100, -1));

        colabtn.setBackground(new java.awt.Color(0, 0, 0));
        colabtn.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        colabtn.setForeground(new java.awt.Color(255, 255, 255));
        colabtn.setText("ADD");
        colabtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                colabtnActionPerformed(evt);
            }
        });
        jPanel3.add(colabtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 100, -1));

        btnlemonade.setBackground(new java.awt.Color(0, 0, 0));
        btnlemonade.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnlemonade.setForeground(new java.awt.Color(255, 255, 255));
        btnlemonade.setText("ADD");
        btnlemonade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlemonadeActionPerformed(evt);
            }
        });
        jPanel3.add(btnlemonade, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 240, 100, -1));

        btnEnergydrink.setBackground(new java.awt.Color(0, 0, 0));
        btnEnergydrink.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnEnergydrink.setForeground(new java.awt.Color(255, 255, 255));
        btnEnergydrink.setText("ADD");
        btnEnergydrink.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnergydrinkActionPerformed(evt);
            }
        });
        jPanel3.add(btnEnergydrink, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 240, 100, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("RM3.20");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 460, 100, -1));

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setText("RM2.50");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 220, 100, -1));

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setText("RM3.00");
        jPanel3.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 220, 100, -1));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("RM2.50");
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 220, 100, -1));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel12.setText("RM2.00");
        jPanel3.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 460, 100, -1));

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setText("RM2.50");
        jPanel3.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 460, 110, -1));

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel23.setText("RM1.50");
        jPanel3.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 460, 100, -1));

        jLabel24.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel24.setText("RM2.00");
        jPanel3.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, 100, -1));

        jLabel25.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel25.setText("RM4.50");
        jPanel3.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, 90, -1));

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/iced-tea.png"))); // NOI18N
        jLabel20.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 300, 110, 150));

        jLabel26.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icon/lemonade.png"))); // NOI18N
        jLabel26.setVerticalAlignment(javax.swing.SwingConstants.BOTTOM);
        jPanel3.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 40, 120, 150));

        jLabel17Cola.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel17Cola.setText("RM2.50");
        jPanel3.add(jLabel17Cola, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 220, 100, -1));

        jLabel28MineralWater.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel28MineralWater.setText("Mineral water ");
        jPanel3.add(jLabel28MineralWater, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 440, 150, -1));

        jLabel100plus.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel100plus.setText("100 plus");
        jPanel3.add(jLabel100plus, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 440, 150, -1));

        jLabel30apple.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel30apple.setText("Apple juice");
        jPanel3.add(jLabel30apple, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 440, 150, -1));

        jLabel31coconut.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel31coconut.setText("Coconut water");
        jPanel3.add(jLabel31coconut, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 440, 150, -1));

        jLabel32lemon.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel32lemon.setText("Lemonade");
        jPanel3.add(jLabel32lemon, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 200, 150, -1));

        jLabel33coffee.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel33coffee.setText("Coffee");
        jPanel3.add(jLabel33coffee, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 200, 150, -1));

        jLabel27icedLemon.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel27icedLemon.setText("Iced lemon tea");
        jPanel3.add(jLabel27icedLemon, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 440, 150, -1));

        jLabel36pepsi.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel36pepsi.setText("Pepsi");
        jPanel3.add(jLabel36pepsi, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 200, 100, -1));

        jLabel37cola.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel37cola.setText("Coca Cola");
        jPanel3.add(jLabel37cola, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 200, 100, -1));

        jLabel38energy.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel38energy.setText("Energy drink");
        jPanel3.add(jLabel38energy, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 200, 110, -1));

        jPanel2.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 80, 710, 550));

        jLabel9.setBackground(new java.awt.Color(0, 0, 0));
        jLabel9.setFont(new java.awt.Font("Tw Cen MT Condensed Extra Bold", 1, 48)); // NOI18N
        jLabel9.setText("X");
        jLabel9.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel9MouseClicked(evt);
            }
        });
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1450, 10, -1, 45));

        jPanel4.setBackground(new java.awt.Color(51, 51, 51));
        jPanel4.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(102, 51, 0), 4));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jInsertMoney.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jInsertMoneyFocusLost(evt);
            }
        });
        jPanel4.add(jInsertMoney, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 320, 190, 30));

        jChange.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jChangeActionPerformed(evt);
            }
        });
        jPanel4.add(jChange, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 370, 190, 30));

        jTotal.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jTotal.setForeground(new java.awt.Color(255, 255, 255));
        jTotal.setText("Total: ");
        jPanel4.add(jTotal, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 270, 250, 30));

        jQuantity.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jQuantity.setForeground(new java.awt.Color(255, 255, 255));
        jQuantity.setText("Total Quantity: ");
        jPanel4.add(jQuantity, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 320, 30));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Insert Money:");
        jPanel4.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 130, 30));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Change:");
        jPanel4.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 370, 80, 30));

        btnPurchase.setBackground(new java.awt.Color(0, 0, 0));
        btnPurchase.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnPurchase.setForeground(new java.awt.Color(255, 255, 255));
        btnPurchase.setText("Purchase");
        btnPurchase.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPurchaseActionPerformed(evt);
            }
        });
        jPanel4.add(btnPurchase, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 430, -1, -1));

        btnClearAll.setBackground(new java.awt.Color(0, 0, 0));
        btnClearAll.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnClearAll.setForeground(new java.awt.Color(255, 255, 255));
        btnClearAll.setText("Clear All");
        btnClearAll.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnClearAllActionPerformed(evt);
            }
        });
        jPanel4.add(btnClearAll, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 430, -1, -1));

        jRecipt.setColumns(20);
        jRecipt.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        jRecipt.setRows(5);
        jRecipt.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jScrollPane2.setViewportView(jRecipt);

        jPanel4.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 10, 300, 470));

        CartArea.setColumns(20);
        CartArea.setFont(new java.awt.Font("Monospaced", 1, 18)); // NOI18N
        CartArea.setRows(5);
        CartArea.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 2));
        jScrollPane1.setViewportView(CartArea);

        jPanel4.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 360, 200));

        jPanel2.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 80, 740, 490));

        jButton1.setFont(new java.awt.Font("Nirmala UI", 1, 24)); // NOI18N
        jButton1.setText("EXIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(960, 600, 300, 50));

        getContentPane().add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1500, 670));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnCoconutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCoconutActionPerformed
        // TODO add your handling code here
        handleDrinkButton(1);


    }//GEN-LAST:event_btnCoconutActionPerformed

    private void btnlemonteaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlemonteaActionPerformed
        // TODO add your handling code here:
        handleDrinkButton(2);

    }//GEN-LAST:event_btnlemonteaActionPerformed

    private void btnWaterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWaterActionPerformed
        // TODO add your handling code here:
        handleDrinkButton(3);

    }//GEN-LAST:event_btnWaterActionPerformed

    private void btn100plusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn100plusActionPerformed
        // TODO add your handling code here:
        handleDrinkButton(4);

    }//GEN-LAST:event_btn100plusActionPerformed

    private void btnAppleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAppleActionPerformed
        // TODO add your handling code here:
        handleDrinkButton(5);

    }//GEN-LAST:event_btnAppleActionPerformed

    private void btnlemonadeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlemonadeActionPerformed
        // TODO add your handling code here:
        handleDrinkButton(6);

    }//GEN-LAST:event_btnlemonadeActionPerformed

    private void colabtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_colabtnActionPerformed
        // TODO add your handling code here:
        handleDrinkButton(7);


    }//GEN-LAST:event_colabtnActionPerformed

    private void btnEnergydrinkActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnergydrinkActionPerformed
        // TODO add your handling code here:
        handleDrinkButton(8);

    }//GEN-LAST:event_btnEnergydrinkActionPerformed

    private void btnCoffeeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCoffeeActionPerformed
        // TODO add your handling code here:
        handleDrinkButton(9);

    }//GEN-LAST:event_btnCoffeeActionPerformed

    private void btnPepsiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPepsiActionPerformed
        // TODO add your handling code here:
        handleDrinkButton(10);

    }//GEN-LAST:event_btnPepsiActionPerformed

    private void jLabel9MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel9MouseClicked
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jLabel9MouseClicked

    private void btnClearAllActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnClearAllActionPerformed
    // Clear drink quantities and total amount
    for (Drink drink : drinksList) {
        drink.setQuantity(0); // Reset the drink quantity
    }
    totalAmount = 0;

    // Update total quantity and total amount displays
    updateTotalQuantity();
    updateTotalAmount();

    // Clear cart area
    CartArea.setText("");
    jReceipt.setText("");
    jChange.setText("");
    jInsertMoney.setText("RM");


    // Clear the temporary drink quantity map
    tempDrinkQuantityMap.clear();

    // Reset tempDrinkQuantityMap to match drinkQuantityMap
    tempDrinkQuantityMap.putAll(drinkQuantityMap);
    
    clearCart();


    }//GEN-LAST:event_btnClearAllActionPerformed


    private void btnPurchaseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPurchaseActionPerformed
        // Get the inserted money
        String insertedMoneyText = jInsertMoney.getText().replace("RM", "").trim();
        if (insertedMoneyText.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please insert money.");
            return;
        }

        // Check if the input is numeric
        if (!checkNum(insertedMoneyText)) {
            JOptionPane.showMessageDialog(null, "Invalid input. Please enter a valid number.");
            return;
        }

        double insertedMoney = Double.parseDouble(insertedMoneyText);

        // Calculate the total price and build purchase history content
        double totalPrice = 0;
        StringBuilder purchaseHistoryContent = new StringBuilder();

        // Determine the next available purchase ID
        int nextPurchaseId = getLastPurchaseIdFromFile("purchaseHistory.txt") + 1;

        for (Drink drink : drinksList) {
            int purchasedQuantity = tempDrinkQuantityMap.getOrDefault(drink.getName(), 0);
            if (purchasedQuantity > 0) {
                double drinkTotalPrice = drink.getPrice() * purchasedQuantity;
                totalPrice += drinkTotalPrice;

                // Append to purchase history content
                purchaseHistoryContent.append(nextPurchaseId + ", " + drink.getId() + ", " + drink.getName() + ", " + purchasedQuantity + ", " + String.format("%.2f", drinkTotalPrice) + "\n");
                nextPurchaseId++;

                // Update the drink quantity in the file
                updateDrinkQuantityInFile(drink.getName(), purchasedQuantity);
            }
        }

        if (insertedMoney < totalPrice) {
            JOptionPane.showMessageDialog(null, "Not enough money. Please insert more.");
            return;
        }

        double change = insertedMoney - totalPrice;
        jChange.setText("RM " + String.format("%.2f", change));

        // Save purchase history to file
        savePurchaseHistoryToFile("purchaseHistory.txt", purchaseHistoryContent.toString());

        // Generate receipt content
        StringBuilder receiptContent = new StringBuilder();
        receiptContent.append("--------------------Receipt------------------------\n\n");
        receiptContent.append("Purchased Items:\n");

        for (Drink drink : drinksList) {
            int purchasedQuantity = tempDrinkQuantityMap.getOrDefault(drink.getName(), 0);
            if (purchasedQuantity > 0) {
                double drinkTotalPrice = drink.getPrice() * purchasedQuantity;
                receiptContent.append(purchasedQuantity + " x " + drink.getName() + " RM " + String.format("%.2f", drinkTotalPrice) + "\n"); 
            }
        }

        receiptContent.append("\n");
        receiptContent.append("------------------------------------------------------\n");
        receiptContent.append("Total Amount: RM " + String.format("%.2f", totalPrice) + "\n");
        receiptContent.append("Total Amount Paid: RM " + String.format("%.2f", insertedMoney) + "\n");
        receiptContent.append("Change: RM " + String.format("%.2f", change) + "\n");
        receiptContent.append("------------------------------------------------------\n");

        jReceipt.setText(receiptContent.toString());

        int fontSize = 14;
        Font font = new Font("Arial", Font.PLAIN, fontSize);
        jReceipt.setFont(font);

        jInsertMoney.setText("RM");

        // Clear and reload the drink data
        drinksList.clear();
        loadDrinkDataFromFile("D:/Darren/Documents/NetBeansProjects/VendingMachine/drinksData.txt");

        // After loading the data, update the availability of text fields and UI components
        tempDrinkQuantityMap.clear();
JOptionPane.showMessageDialog(null, "Purchase successful. Thank you!");

    }//GEN-LAST:event_btnPurchaseActionPerformed

    private void jChangeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jChangeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jChangeActionPerformed

    private void jInsertMoneyFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jInsertMoneyFocusLost
        // TODO add your handling code here:
        String text = jInsertMoney.getText().trim();
        if (!text.startsWith("RM")) {
            jInsertMoney.setText("RM" + text);
        }


    }//GEN-LAST:event_jInsertMoneyFocusLost

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        dispose();
        new user_selection().setVisible(true);


    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(customer_purchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(customer_purchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(customer_purchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(customer_purchase.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new customer_purchase().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea CartArea;
    private javax.swing.JButton btn100plus;
    private javax.swing.JButton btnApple;
    private javax.swing.JButton btnClearAll;
    private javax.swing.JButton btnCoconut;
    private javax.swing.JButton btnCoffee;
    private javax.swing.JButton btnEnergydrink;
    private javax.swing.JButton btnPepsi;
    private javax.swing.JButton btnPurchase;
    private javax.swing.JButton btnWater;
    private javax.swing.JButton btnlemonade;
    private javax.swing.JButton btnlemontea;
    private javax.swing.JButton colabtn;
    private javax.swing.JButton jButton1;
    private javax.swing.JTextField jChange;
    private javax.swing.JTextField jInsertMoney;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    public javax.swing.JLabel jLabel100plus;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17Cola;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    public javax.swing.JLabel jLabel27icedLemon;
    public javax.swing.JLabel jLabel28MineralWater;
    private javax.swing.JLabel jLabel3;
    public javax.swing.JLabel jLabel30apple;
    public javax.swing.JLabel jLabel31coconut;
    public javax.swing.JLabel jLabel32lemon;
    public javax.swing.JLabel jLabel33coffee;
    public javax.swing.JLabel jLabel36pepsi;
    public javax.swing.JLabel jLabel37cola;
    public javax.swing.JLabel jLabel38energy;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JLabel jQuantity;
    private javax.swing.JTextArea jRecipt;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel jTotal;
    // End of variables declaration//GEN-END:variables
}
